# Cookiedough

Chrome extension that lets you bulk set cookies based on a verbatim cookie header. You can find it in the Chrome store as "Cookiedough".
 
