import * as React from "react";
import * as ReactDOM from "react-dom";
import {PopupApp} from "./PopupApp";

ReactDOM.render(
	<PopupApp />,
	document.getElementById("app")
);
